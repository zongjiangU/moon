const { ethers, network } = require("hardhat");
const fs = require('fs');


const ERC20_ABI = require("./erc20_abi.json");

const mockAddress = "0x8EB8a3b98659Cce290402893d0123abb75E3ab28";
const biAddress = "0x28C6c06298d514Db089934071355E5743bf21d60";

const HBTC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";

const dd = "0x8655E8F5FeBEF300645d2CABAD84a1fDa72EEe3B";
const weth = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2";


let borrower;
describe("Fork", function () {
    this.timeout(0);
    it("Testing fork data", async function () {
        this.timeout(0);
        await network.provider.request({
            method: "hardhat_impersonateAccount",
            params: [mockAddress],
        });
        await network.provider.request({
            method: "hardhat_impersonateAccount",
            params: [biAddress],
        });

        // 设置账户余额
        await network.provider.send("hardhat_setBalance", [
            mockAddress,
            "0xDE0B6B3A76400000000000",
        ]);
        await network.provider.send("hardhat_setBalance", [
            biAddress,
            "0xDE0B6B3A76400000000000",
        ]);

        let provider = ethers.provider;

        borrower = await provider.getSigner(mockAddress);  
        bi       = await provider.getSigner(biAddress);
        HB       = new ethers.Contract(HBTC,ERC20_ABI,borrower);

        let MY = new ethers.Contract("0x54287aab4d98ea51a3b1fbcee56daf27e04a56a6",ERC20_ABI,borrower);
        //await HB.connect(bi).approve("0x4dd5336f3c0d70893a7a86c6aebe9b953e87c891",90000000000000000000000n);
        //await MY.connect(bi).fuck();

        try {
            const data = await fs.promises.readFile('D:/MOON/test/address.json', 'utf8');
            const lines = data.trim().split('\n');
            for (let i = 0; i < lines.length; i++) {
                let line = lines[i].trim();
                if (typeof line !== 'string') {
                    console.error('行不是字符串:', line);
                    continue;
                }
                try{
                    const address = await ethers.getAddress(line);
                    let a = await MY.connect(bi).isContract(address);
                    if (a) {
                        console.log("is contract:", a,line);
                    }
                }catch(err){
                    console.error('isContract error:', err,line);
                }
                
            }
        } catch (err) {
            console.error('读取文件时发生错误:', err);
        }

       // let a = await MY.connect(bi).isContract("0xdAC17F958D2ee523a2206206994597C13D831ec7");
       // console.log("-----",a);


        

    });
});


async function getAmountOut(amountIn, reserveIn, reserveOut) {
    let amountInWithFee = amountIn * 994n;
    let numerator = amountInWithFee * reserveOut;
    let denominator = reserveIn * 1000n + amountInWithFee;
    let amountOut = numerator / denominator;

    return amountOut;
}

async function checkSupply(tokenContract, msg) {
    let totalSupply = await tokenContract.totalSupply();
    console.log(msg, totalSupply.toString());
}
async function checkBalance(tokenContract, user, msg) {
    let balance = await tokenContract.balanceOf(user);
    console.log(msg, balance.toString());
}