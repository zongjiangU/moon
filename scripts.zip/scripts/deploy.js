// scripts/deploy.js

async function main() {
    // 获取合约工厂
    const MyContract = await ethers.getContractFactory("BZX");

    // 部署合约
    const myContract = await MyContract.deploy();

    console.log("合约已部署到地址:", myContract.address);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
